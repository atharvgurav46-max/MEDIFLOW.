@echo off
title MEDIFLOW Server & Backend
echo =======================================================
echo   Starting MEDIFLOW Hospital Management System...
echo =======================================================
if exist "%~dp0node.exe" (
  "%~dp0node.exe" "%~dp0server.js"
) else (
  node "%~dp0server.js"
)
pause
