const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const url = require("node:url");
const crypto = require("node:crypto");

const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "database.json");

// --- PASSWORD & TOKEN UTILITIES (Zero external dependencies) ---
function hashPassword(password, salt) {
  if (!salt) salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  if (!password || !salt || !hash) return false;
  const check = crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
  return check === hash;
}

function generateToken() {
  return crypto.randomBytes(32).toString("hex");
}

// Medicine Catalog for initial inventory seeding
const INITIAL_DEPARTMENTS = {
  "Cardiology": ["Amlodipine", "Atorvastatin", "Aspirin", "Clopidogrel", "Metoprolol"],
  "Neurology": ["Levetiracetam", "Gabapentin", "Pregabalin", "Vitamin B Complex", "Neurological Support Medicine"],
  "Oncology": ["Supportive Care Medicine", "Anti-nausea Medicine", "Oral Care Medicine", "Vitamin Supplement", "Sterile Dressing"],
  "Nephrology / Dialysis": ["Calcium Supplement", "Iron Supplement", "Vitamin D Supplement", "Erythropoietin Support Item", "Dialysis Dressing"],
  "Orthopedics": ["Calcium Supplement", "Vitamin D", "Pain Relief Medicine", "Elastic Bandage", "Sterile Bandage"],
  "General Medicine": ["Paracetamol", "Antibiotic", "Vitamin B Complex", "ORS", "Cough Medicine"],
  "General Surgery": ["Antibiotic", "Pain Relief Medicine", "Antiseptic Solution", "Sterile Gauze", "Surgical Dressing"],
  "Pediatrics": ["Pediatric Paracetamol", "Pediatric ORS", "Vitamin Drops", "Pediatric Antibiotic", "Pediatric Syrup"],
  "Gynecology & Obstetrics": ["Iron Supplement", "Folic Acid", "Calcium Supplement", "Vitamin Supplement", "Maternity Support Items"],
  "Pulmonology": ["Inhaler", "Respiratory Medicine", "Cough Medicine", "Nebulization Solution", "Allergy Medicine"],
  "Gastroenterology": ["Antacid", "Acid Reduction Medicine", "Digestive Medicine", "ORS", "Probiotic"],
  "Urology": ["Urinary Care Medicine", "Antibiotic", "Pain Relief Medicine", "Electrolyte Solution", "Supportive Medicine"],
  "Endocrinology": ["Diabetes Medicine", "Thyroid Medicine", "Calcium Supplement", "Vitamin D", "Glucose Monitoring Strips"],
  "ENT": ["Ear Drops", "Nasal Spray", "Throat Medicine", "Antibiotic", "Allergy Medicine"],
  "Ophthalmology": ["Eye Drops", "Lubricating Eye Drops", "Eye Antibiotic", "Eye Dressing", "Eye Care Medicine"],
  "Dermatology": ["Skin Cream", "Antifungal Cream", "Antibiotic Cream", "Skin Lotion", "Dressing Material"],
  "Psychiatry": ["Prescribed Mental Health Medicine", "Sleep Support Medicine", "Vitamin Supplement", "General Supportive Medicine"],
  "Emergency & Trauma": ["Emergency Medicine", "IV Fluid", "Sterile Bandage", "Gauze", "Antiseptic", "Emergency Dressing Kit"],
  "ICU": ["Critical Care Medicine", "IV Fluid", "Sterile Dressing", "Syringes", "Gloves", "ICU Support Items"],
  "Infectious Disease": ["Antibiotic", "Antiviral Support Medicine", "ORS", "Fever Medicine", "Vitamin Supplement"]
};

const PRICE_OVERRIDES = {
  "Aspirin": 90, "Atorvastatin": 180, "Metoprolol": 145, "Calcium Supplement": 250,
  "Vitamin B Complex": 180, "Sterile Bandage": 120, "Bandage": 120,
  "Amlodipine": 110, "Clopidogrel": 210, "Paracetamol": 45, "ORS": 35,
  "Iron Supplement": 160, "Folic Acid": 85, "Vitamin D": 130, "Vitamin D Supplement": 150
};

function buildInitialInventory() {
  const inv = {};
  let index = 0;
  Object.entries(INITIAL_DEPARTMENTS).forEach(([dept, meds]) => {
    meds.forEach((name) => {
      if (!inv[name]) {
        const price = PRICE_OVERRIDES[name] || (75 + ((name.length * 29 + index * 17) % 195));
        const quantity = 15 + ((index * 7 + name.length * 3) % 45);
        inv[name] = {
          name,
          departments: [dept],
          quantity,
          price
        };
        index++;
      } else if (!inv[name].departments.includes(dept)) {
        inv[name].departments.push(dept);
      }
    });
  });
  return inv;
}

function buildDefaultUsers() {
  const docSalt = crypto.randomBytes(16).toString("hex");
  const staffSalt = crypto.randomBytes(16).toString("hex");
  const relSalt = crypto.randomBytes(16).toString("hex");
  const adminSalt = crypto.randomBytes(16).toString("hex");

  return [
    {
      id: "USR-DOC-001",
      name: "Dr. Kavita Rao",
      username: "dr.kavita",
      email: "doctor@hospital.com",
      role: "doctor",
      department: "Cardiology",
      mobile: "9820011223",
      salt: docSalt,
      passwordHash: hashPassword("doctor123", docSalt).hash,
      createdAt: new Date().toISOString()
    },
    {
      id: "USR-STF-001",
      name: "Anita Mehta",
      username: "anita.mehta",
      email: "staff@hospital.com",
      role: "staff",
      department: "Central Pharmacy",
      mobile: "9820022334",
      salt: staffSalt,
      passwordHash: hashPassword("staff123", staffSalt).hash,
      createdAt: new Date().toISOString()
    },
    {
      id: "USR-REL-001",
      name: "Suresh Patil",
      username: "suresh.patil",
      email: "relative@hospital.com",
      role: "relative",
      department: "Patient Relative",
      mobile: "9876543210",
      salt: relSalt,
      passwordHash: hashPassword("relative123", relSalt).hash,
      createdAt: new Date().toISOString()
    },
    {
      id: "USR-ADM-001",
      name: "Hospital Administrator",
      username: "admin",
      email: "admin@hospital.com",
      role: "admin",
      department: "Hospital Administration",
      mobile: "9820099887",
      salt: adminSalt,
      passwordHash: hashPassword("admin123", adminSalt).hash,
      createdAt: new Date().toISOString()
    }
  ];
}

// Ensure database file exists and is populated
function readDB() {
  try {
    let data;
    if (!fs.existsSync(DB_FILE)) {
      data = {
        version: 4,
        updatedAt: new Date().toISOString(),
        users: buildDefaultUsers(),
        sessions: [],
        prescriptions: [],
        inventory: buildInitialInventory(),
        notifications: [
          {
            id: `N-${Date.now()}-welcome`,
            title: "MEDIFLOW System Initialized",
            message: "Real authentication and backend database server active.",
            createdAt: Date.now(),
            read: false
          }
        ]
      };
      writeDB(data);
      return data;
    }

    data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    let changed = false;

    if (!Array.isArray(data.users) || data.users.length === 0) {
      data.users = buildDefaultUsers();
      changed = true;
    }
    if (!Array.isArray(data.sessions)) {
      data.sessions = [];
      changed = true;
    }
    if (!Array.isArray(data.prescriptions)) {
      data.prescriptions = [];
      changed = true;
    }
    if (!data.inventory || Object.keys(data.inventory).length === 0) {
      data.inventory = buildInitialInventory();
      changed = true;
    }
    if (!Array.isArray(data.notifications)) {
      data.notifications = [];
      changed = true;
    }
    data.version = 4;

    if (changed) {
      writeDB(data);
    }
    return data;
  } catch (err) {
    console.error("Error reading database:", err);
    return {
      version: 4,
      users: buildDefaultUsers(),
      sessions: [],
      prescriptions: [],
      inventory: buildInitialInventory(),
      notifications: []
    };
  }
}

// Atomic write to prevent file corruption
function writeDB(data) {
  try {
    data.updatedAt = new Date().toISOString();
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), "utf8");
    fs.renameSync(tempFile, DB_FILE);
    return true;
  } catch (err) {
    console.error("Error writing database:", err);
    return false;
  }
}

// Clean up expired sessions (older than 7 days)
function cleanExpiredSessions(db) {
  const SEVEN_DAYS = 7 * 24 * 60 * 60 * 1000;
  const now = Date.now();
  const valid = (db.sessions || []).filter((s) => now - s.createdAt < SEVEN_DAYS);
  if (valid.length !== (db.sessions || []).length) {
    db.sessions = valid;
    writeDB(db);
  }
}

// Helper to sanitize user object for client responses
function sanitizeUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    username: u.username,
    role: u.role,
    department: u.department || "",
    mobile: u.mobile || "",
    createdAt: u.createdAt
  };
}

// Resolve user from Authorization header
function getAuthUser(req, db) {
  const authHeader = req.headers["authorization"] || req.headers["x-auth-token"] || "";
  let token = "";
  if (authHeader.startsWith("Bearer ")) {
    token = authHeader.slice(7).trim();
  } else {
    token = authHeader.trim();
  }
  if (!token) return null;

  cleanExpiredSessions(db);
  const session = (db.sessions || []).find((s) => s.token === token);
  if (!session) return null;

  const user = (db.users || []).find((u) => u.id === session.userId);
  return user ? sanitizeUser(user) : null;
}

// MIME types dictionary for static files
const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".pdf": "application/pdf"
};

const server = http.createServer((req, res) => {
  // Enable CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Auth-Token");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // JSON Response Helper
  function sendJSON(statusCode, payload) {
    res.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload));
  }

  // JSON Body Parser Helper
  function getRequestBody(callback) {
    let body = "";
    req.on("data", (chunk) => { body += chunk; });
    req.on("end", () => {
      try {
        const parsed = body ? JSON.parse(body) : {};
        callback(null, parsed);
      } catch (e) {
        callback(e, null);
      }
    });
  }

  // ==========================================
  // --- REAL AUTHENTICATION & USER ROUTES ---
  // ==========================================

  // POST /api/auth/register - Register a new user account
  if (pathname === "/api/auth/register" && req.method === "POST") {
    getRequestBody((err, body) => {
      if (err || !body) return sendJSON(400, { error: "Invalid JSON payload" });

      const name = String(body.name || "").trim();
      const identifier = String(body.username || body.email || "").trim().toLowerCase();
      const email = String(body.email || (identifier.includes("@") ? identifier : `${identifier}@hospital.local`)).trim().toLowerCase();
      const username = String(body.username || (identifier.includes("@") ? identifier.split("@")[0] : identifier)).trim().toLowerCase();
      const password = String(body.password || "");
      const role = String(body.role || "relative").toLowerCase();
      const department = String(body.department || "").trim();
      const mobile = String(body.mobile || "").trim();

      if (!name) return sendJSON(400, { error: "Full name is required" });
      if (!identifier || (!email && !username)) return sendJSON(400, { error: "Username or email is required" });
      if (!password || password.length < 6) return sendJSON(400, { error: "Password must be at least 6 characters" });
      if (!["doctor", "staff", "relative", "admin"].includes(role)) {
        return sendJSON(400, { error: "Role must be doctor, staff, relative, or admin" });
      }

      const db = readDB();
      const exists = db.users.some(
        (u) => u.email.toLowerCase() === email || u.username.toLowerCase() === username
      );
      if (exists) {
        return sendJSON(409, { error: "An account with this email or username already exists" });
      }

      const { salt, hash } = hashPassword(password);
      const prefix = role.toUpperCase().slice(0, 3);
      const userId = `USR-${prefix}-${Date.now().toString().slice(-6)}`;

      const newUser = {
        id: userId,
        name,
        email,
        username,
        role,
        department: department || (role === "doctor" ? "General Medicine" : role === "staff" ? "Central Pharmacy" : "Patient Relative"),
        mobile: mobile || "",
        salt,
        passwordHash: hash,
        createdAt: new Date().toISOString()
      };

      db.users.push(newUser);

      // Generate active session
      const token = generateToken();
      db.sessions.push({
        token,
        userId: newUser.id,
        createdAt: Date.now()
      });

      writeDB(db);

      return sendJSON(201, {
        message: "Account created successfully",
        token,
        user: sanitizeUser(newUser)
      });
    });
    return;
  }

  // POST /api/auth/login - Real login with credentials verification
  if (pathname === "/api/auth/login" && req.method === "POST") {
    getRequestBody((err, body) => {
      if (err || !body) return sendJSON(400, { error: "Invalid JSON payload" });

      const identifier = String(body.identifier || body.username || body.email || "").trim().toLowerCase();
      const password = String(body.password || "");

      if (!identifier || !password) {
        return sendJSON(400, { error: "Username/email and password are required" });
      }

      const db = readDB();
      const user = db.users.find(
        (u) => u.email.toLowerCase() === identifier || u.username.toLowerCase() === identifier
      );

      if (!user) {
        return sendJSON(401, { error: "Invalid username or password" });
      }

      const valid = verifyPassword(password, user.salt, user.passwordHash);
      if (!valid) {
        return sendJSON(401, { error: "Invalid username or password" });
      }

      // Generate session token
      const token = generateToken();
      db.sessions.push({
        token,
        userId: user.id,
        createdAt: Date.now()
      });

      writeDB(db);

      return sendJSON(200, {
        message: "Login successful",
        token,
        user: sanitizeUser(user)
      });
    });
    return;
  }

  // GET /api/auth/me - Validate token & get current profile
  if (pathname === "/api/auth/me" && req.method === "GET") {
    const db = readDB();
    const user = getAuthUser(req, db);
    if (!user) {
      return sendJSON(401, { error: "Unauthorized. Please log in." });
    }
    return sendJSON(200, { user });
  }

  // POST /api/auth/logout - Invalidate current session
  if (pathname === "/api/auth/logout" && req.method === "POST") {
    const authHeader = req.headers["authorization"] || req.headers["x-auth-token"] || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : authHeader.trim();
    if (token) {
      const db = readDB();
      db.sessions = (db.sessions || []).filter((s) => s.token !== token);
      writeDB(db);
    }
    return sendJSON(200, { message: "Signed out successfully" });
  }

  // GET /api/auth/users - List users (for admin / staff directory)
  if (pathname === "/api/auth/users" && req.method === "GET") {
    const db = readDB();
    return sendJSON(200, {
      users: db.users.map(sanitizeUser)
    });
  }

  // ==========================================
  // --- SYSTEM & STATS ROUTES ---
  // ==========================================

  // GET /api/status - Health check
  if (pathname === "/api/status" && req.method === "GET") {
    const db = readDB();
    return sendJSON(200, {
      status: "connected",
      environment: "production",
      database: "database.json",
      totalUsers: db.users.length,
      totalPrescriptions: db.prescriptions.length,
      totalInventoryItems: Object.keys(db.inventory || {}).length,
      updatedAt: db.updatedAt
    });
  }

  // GET /api/stats - Dashboard analytics
  if (pathname === "/api/stats" && req.method === "GET") {
    const db = readDB();
    const list = db.prescriptions || [];
    const total = list.length;
    const completed = list.filter((p) => p.status === "COLLECTED").length;
    const emergency = list.filter((p) => p.priority === "HIGH").length;
    const active = list.filter((p) => p.status !== "COLLECTED").length;
    const billed = list.filter((p) => p.status === "BILLED" || p.status === "PREPARING" || p.status === "READY" || p.status === "COLLECTED").length;

    return sendJSON(200, {
      total,
      active,
      completed,
      emergency,
      billed,
      efficiency: total ? Math.round((completed / total) * 100) : 0,
      updatedAt: db.updatedAt
    });
  }

  // ==========================================
  // --- PRESCRIPTIONS API ROUTES ---
  // ==========================================

  // GET /api/prescriptions - Fetch all prescriptions
  if (pathname === "/api/prescriptions" && req.method === "GET") {
    const db = readDB();
    return sendJSON(200, { prescriptions: db.prescriptions });
  }

  // GET /api/prescriptions/:id - Fetch single prescription
  if (pathname.startsWith("/api/prescriptions/") && req.method === "GET") {
    const id = decodeURIComponent(pathname.replace("/api/prescriptions/", ""));
    const db = readDB();
    const prescription = db.prescriptions.find((p) => p.prescriptionId === id);
    if (!prescription) {
      return sendJSON(404, { error: "Prescription not found" });
    }
    return sendJSON(200, { prescription });
  }

  // POST /api/prescriptions - Create & save new prescription
  if (pathname === "/api/prescriptions" && req.method === "POST") {
    getRequestBody((err, body) => {
      if (err || !body || !body.prescriptionId) {
        return sendJSON(400, { error: "Invalid prescription payload" });
      }

      const db = readDB();
      const existingIndex = db.prescriptions.findIndex((p) => p.prescriptionId === body.prescriptionId);

      const record = {
        ...body,
        updatedAt: Date.now()
      };

      if (existingIndex >= 0) {
        db.prescriptions[existingIndex] = { ...db.prescriptions[existingIndex], ...record };
      } else {
        db.prescriptions.unshift(record);
      }

      // Add audit notification for pharmacy staff
      db.notifications.unshift({
        id: `N-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: record.priority === "HIGH" ? "🚨 Emergency Prescription" : "New Prescription Received",
        message: `${record.patientName} (${record.prescriptionId}) from ${record.department || "Clinic"}.`,
        prescriptionId: record.prescriptionId,
        createdAt: Date.now(),
        read: false
      });
      db.notifications = db.notifications.slice(0, 100);

      writeDB(db);
      return sendJSON(201, {
        message: "Prescription stored successfully in database",
        prescription: record
      });
    });
    return;
  }

  // PUT /api/prescriptions/:id - Update prescription
  if (pathname.startsWith("/api/prescriptions/") && req.method === "PUT") {
    const id = decodeURIComponent(pathname.replace("/api/prescriptions/", ""));
    getRequestBody((err, body) => {
      if (err || !body) return sendJSON(400, { error: "Invalid JSON" });

      const db = readDB();
      const index = db.prescriptions.findIndex((p) => p.prescriptionId === id);
      if (index === -1) {
        return sendJSON(404, { error: "Prescription not found" });
      }

      const prevStatus = db.prescriptions[index].status;
      const updated = {
        ...db.prescriptions[index],
        ...body,
        updatedAt: Date.now()
      };
      db.prescriptions[index] = updated;

      // Status change notifications
      if (body.status && body.status !== prevStatus) {
        if (body.status === "READY") {
          db.notifications.unshift({
            id: `N-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            title: "Medicine Ready for Collection",
            message: `${updated.patientName}'s medicine is packed and ready at ${updated.counter || "Counter 1"}.`,
            prescriptionId: updated.prescriptionId,
            createdAt: Date.now(),
            read: false
          });
        }
      }

      writeDB(db);
      return sendJSON(200, {
        message: "Prescription updated in database",
        prescription: updated
      });
    });
    return;
  }

  // DELETE /api/prescriptions/:id - Remove prescription
  if (pathname.startsWith("/api/prescriptions/") && req.method === "DELETE") {
    const id = decodeURIComponent(pathname.replace("/api/prescriptions/", ""));
    const db = readDB();
    const before = db.prescriptions.length;
    db.prescriptions = db.prescriptions.filter((p) => p.prescriptionId !== id);
    if (db.prescriptions.length === before) {
      return sendJSON(404, { error: "Prescription not found" });
    }
    writeDB(db);
    return sendJSON(200, { message: "Prescription deleted from database" });
  }

  // ==========================================
  // --- INVENTORY API ROUTES ---
  // ==========================================

  // GET /api/inventory - Get medicine stock catalog
  if (pathname === "/api/inventory" && req.method === "GET") {
    const db = readDB();
    return sendJSON(200, { inventory: db.inventory || {} });
  }

  // PUT /api/inventory/:name - Update stock quantity or price
  if (pathname.startsWith("/api/inventory/") && req.method === "PUT") {
    const name = decodeURIComponent(pathname.replace("/api/inventory/", ""));
    getRequestBody((err, body) => {
      if (err || !body) return sendJSON(400, { error: "Invalid JSON" });

      const db = readDB();
      if (!db.inventory) db.inventory = {};

      if (!db.inventory[name]) {
        db.inventory[name] = {
          name,
          departments: body.departments || ["General Medicine"],
          quantity: Math.max(0, Number(body.quantity) || 0),
          price: Number(body.price) || 100
        };
      } else {
        if (body.delta != null) {
          db.inventory[name].quantity = Math.max(0, db.inventory[name].quantity + Number(body.delta));
        } else if (body.quantity != null) {
          db.inventory[name].quantity = Math.max(0, Number(body.quantity));
        }
        if (body.price != null) {
          db.inventory[name].price = Number(body.price);
        }
      }

      writeDB(db);
      return sendJSON(200, {
        message: "Inventory item updated",
        item: db.inventory[name]
      });
    });
    return;
  }

  // ==========================================
  // --- NOTIFICATIONS & TRACKING ROUTES ---
  // ==========================================

  // GET /api/notifications - Get notifications
  if (pathname === "/api/notifications" && req.method === "GET") {
    const db = readDB();
    return sendJSON(200, { notifications: db.notifications || [] });
  }

  // POST /api/notifications/read-all - Mark all as read
  if (pathname === "/api/notifications/read-all" && req.method === "POST") {
    const db = readDB();
    (db.notifications || []).forEach((n) => { n.read = true; });
    writeDB(db);
    return sendJSON(200, { message: "Notifications marked as read" });
  }

  // GET /api/track/:query - Search prescription for relatives
  if (pathname.startsWith("/api/track/") && req.method === "GET") {
    const query = decodeURIComponent(pathname.replace("/api/track/", "")).trim().toLowerCase();
    const db = readDB();
    const match = (db.prescriptions || []).find((p) => {
      const pId = String(p.prescriptionId || "").toLowerCase();
      const patId = String(p.patientId || "").toLowerCase();
      const mob = String(p.relativeMobile || "").toLowerCase();
      return pId === query || patId === query || mob === query;
    });

    if (!match) {
      return sendJSON(404, { error: "No prescription found matching this identifier" });
    }
    return sendJSON(200, { prescription: match });
  }

  // POST /api/reset - Clear demo/test prescriptions (keeps users and catalog intact)
  if (pathname === "/api/reset" && req.method === "POST") {
    const db = readDB();
    db.prescriptions = [];
    db.notifications = [
      {
        id: `N-${Date.now()}-reset`,
        title: "Database Cleaned",
        message: "All patient prescriptions cleared. Ready for new entries.",
        createdAt: Date.now(),
        read: false
      }
    ];
    writeDB(db);
    return sendJSON(200, { message: "Prescriptions reset. Database clean." });
  }

  // ==========================================
  // --- STATIC FILE SERVING ---
  // ==========================================
  let filePath = path.join(__dirname, pathname === "/" ? "index.html" : pathname);

  // Security check to avoid directory traversal
  if (!filePath.startsWith(__dirname)) {
    res.writeHead(403, { "Content-Type": "text/plain" });
    res.end("Forbidden");
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Try adding .html
      if (!path.extname(filePath)) {
        filePath += ".html";
      }
    }

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
        res.end("<h1>404 Not Found</h1><p>The requested file was not found on MEDIFLOW server.</p>");
        return;
      }
      const ext = path.extname(filePath).toLowerCase();
      const contentType = MIME_TYPES[ext] || "application/octet-stream";
      res.writeHead(200, { "Content-Type": contentType });
      res.end(content);
    });
  });
});

server.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`  MEDIFLOW Smart Hospital Management & Backend Server`);
  console.log(`  URL: http://localhost:${PORT}`);
  console.log(`  Database: ${DB_FILE}`);
  console.log(`  Authentication: Real JWT/Token Auth & PBKDF2 Hashing`);
  console.log(`  Default Accounts:`);
  console.log(`    - Doctor:   doctor@hospital.com / doctor123`);
  console.log(`    - Staff:    staff@hospital.com  / staff123`);
  console.log(`    - Relative: relative@hospital.com / relative123`);
  console.log(`    - Admin:    admin@hospital.com  / admin123`);
  console.log(`=======================================================`);
});
