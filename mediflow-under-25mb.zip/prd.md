# MEDIFLOW — Real Authentication & Backend Database Specification

## Overview
MEDIFLOW is a Smart Hospital Medicine Queue & Preparation System that digitally coordinates doctors, pharmacy staff, and patient relatives.

## Requirements Fulfilled
1. **Real Authentication System**:
   - Replaced mock/demo login with cryptographically secure PBKDF2 password hashing (1000 iterations, SHA-512, 16-byte random salts).
   - Real token-based session management with 7-day expiration.
   - User registration endpoint (`POST /api/auth/register`) supporting Doctors, Medical Staff, Patient Relatives, and Administrators.
   - Login endpoint (`POST /api/auth/login`) with credential verification and session issuance.
   - Session validation (`GET /api/auth/me`) and secure logout (`POST /api/auth/logout`).
   - Role-based route protection for workspaces (`doctor.html`, `staff.html`, `inventory.html`, `billing.html`).

2. **Backend Database Server (`server.js`)**:
   - Native Node.js HTTP server (zero external npm dependencies required).
   - Atomic file persistence to `database.json` preventing corruption.
   - REST API endpoints for:
     - Authentication: `/api/auth/login`, `/api/auth/register`, `/api/auth/me`, `/api/auth/logout`, `/api/auth/users`
     - Prescriptions CRUD: `GET /api/prescriptions`, `POST /api/prescriptions`, `PUT /api/prescriptions/:id`, `DELETE /api/prescriptions/:id`
     - Stock / Inventory: `GET /api/inventory`, `PUT /api/inventory/:name`
     - Notifications: `GET /api/notifications`, `POST /api/notifications/read-all`
     - Patient Relative Tracking: `GET /api/track/:query`
     - Health & Stats: `GET /api/status`, `GET /api/stats`, `POST /api/reset`

3. **Database Schema & Data Cleanliness**:
   - Default dummy patients (`Rahul Patil`, `Sneha Kulkarni`, etc.) permanently purged.
   - When a doctor creates a prescription, patient details are immediately committed to `database.json` on disk and synced across the network.
   - Initial pre-seeded accounts for immediate testing:
     - **Doctor**: `doctor@hospital.com` / `doctor123`
     - **Medical Staff**: `staff@hospital.com` / `staff123`
     - **Patient Relative**: `relative@hospital.com` / `relative123`
     - **Administrator**: `admin@hospital.com` / `admin123`

4. **Frontend Integration (`js/app.js`, `css/style.css`)**:
   - Modern, responsive Authentication Modal with Sign In, Registration, and 1-Click Quick Fill test buttons.
   - Real-time periodic synchronization between doctor prescriptions and pharmacy staff queue.
   - Self-service tracking portal for relatives by Patient ID, Prescription ID, or Phone Number.
